 function resetFilter(){
		$("#confidVal1").val('0 - 1');
	$("#confidVal2").val('0 - 1');
    $("#rowToFilter").val('500');
	
	$(".badge").html("0");
  
  }
  
  
     
    function hideForm(){
		$("#formContainer").hide();
		 $('#my-awesome-dropzone').hide();
	}
	 
   function showForm(){
		 $("#formContainer").show();
		 $('#my-awesome-dropzone').show();
	}
	
	
function activeBox(){

	$("#confidVal1").removeAttr('disabled');
	$("#confidVal2").removeAttr('disabled');
    $("#rowToFilter").removeAttr('disabled');
	
}


function inactiveBox(){
$("#confidVal1").attr('disabled','disabled');
$("#confidVal2").attr('disabled','disabled');
$("#rowToFilter").attr('disabled','disabled');

}

  

  

  function doubleConfidFilter(data,minVal,maxVal,PosMin,PosMax){
  
		
		var temData=data.filter(function(d,i){
		
			if((d[PosMin].toString()).indexOf(",")!=-1){
			d[PosMin]=parseFloat(d[PosMin].replace(",","."));
		}
			
		if((d[PosMax].toString()).indexOf(",")!=-1){	
			d[PosMax]=parseFloat(d[PosMax].replace(",","."));
		
		}
		
			return (parseFloat(d[PosMin])>= minVal && parseFloat(d[PosMin]) <=maxVal)&&(parseFloat(d[PosMax])>= minVal && parseFloat(d[PosMax]) <=maxVal);
		})
		
		return temData;
		
		
  }
  
  
  function appendTable(newData){
  
  
			newData.forEach(function(d,i){
				
				//if(i!=0){
				
					var td="";
					d.forEach(function(o,j){
					
					
					
					
						if(j>5){
						
						    
							bgColor=getGradientColor(o,newData);
							
							
							td=td+"<td style='background-color:"+bgColor+";color:white'>"+(o.toString()).slice(0,5)+"</td>";
						
						}else{
						
						  td=td+"<td>"+o+"</td>";
						}
						
						
						
						
						
					})
					
					var tr="<tr>"+td+"</tr>";
					
					$("#tbody").append(tr);
				
				//}
			
			});
  
  }
  
  
  function shortTable(){
  
	$('.table').tablesorter();
  
  }
  
  
  
  


function upload(files){
    alert('Upload '+files.length+' File(s).');
}
  
  

  function singleConfidFilter(data,Val,PosMin,PosMax){
	
	var temData=data.filter(function(d,i){
		
		
		
		if((d[PosMin].toString()).indexOf(",")!=-1){
			d[PosMin]=parseFloat(d[PosMin].replace(",","."));
		}
			
		if((d[PosMax].toString()).indexOf(",")!=-1){	
			d[PosMax]=parseFloat(d[PosMax].replace(",","."));
		
		}
			
			
		
			return (parseFloat(d[PosMin]) <=Val)&&( parseFloat(d[PosMax]) <=Val);
		})
		
		
		
		
		return temData;
  
  }
  

  function filterDataForConfid(newData,confid12ValArry,confid23ValArry){
	
		var level1Filter=[];var Level2Filter=[]; 
		
		if(confid12ValArry.length==2){
		
			level1Filter = doubleConfidFilter(newData,confid12ValArry[0],confid12ValArry[1],6,7);
		
		}else{
		
			level1Filter=singleConfidFilter(newData,confid12ValArry[0],6,7)
		}
		
		if(confid23ValArry.length==2){
		
			level2Filter = doubleConfidFilter(level1Filter,confid23ValArry[0],confid23ValArry[1],8,9);
		
		}else{
		
			level2Filter=singleConfidFilter(newData,confid23ValArry[0],8,9)
		}
		
		
		$(".badge").html(level2Filter.length);
		
		return level2Filter;
		
  }



  function processJsonData(data,n,confid12ValArry,confid23ValArry){
  
			$("#tbody tr").remove();
			
			var newData=data.slice(0,n+1);
			
			
			var ConfidFilterData=filterDataForConfid(newData,confid12ValArry,confid23ValArry);
			
			appendTable(ConfidFilterData);
			
			
			
			
			
		setTimeout(function(){
	

			shortTable();
			 
			 
		},500);	
			
			
  
  }

function StartFilter(data){

	
			 var noofRowTofilter=$("#rowToFilter").val();
			 
			 var confid12Val = $("#confidVal1").val();
			 var confid23Val = $("#confidVal2").val();
			 
			 var confid12ValArry=[];
			 
			 var confid23ValArry=[];
			 
			
			 
			 if(confid12Val.indexOf("-")!=-1){
					confid12Split=confid12Val.split("-");
					confid12SplitMin = parseFloat(confid12Split[0].trim());
					confid12SplitMax = parseFloat(confid12Split[1].trim());
					
					
					if(confid12SplitMax==""){
						
						confid12ValArry.push(confid12SplitMin);
					}else{
						if(confid12SplitMax-confid12SplitMin<=0){
							alert("error in confid(1&2) value.")
						
						}else{
						
						
						
							confid12ValArry.push(confid12SplitMin);
							confid12ValArry.push(confid12SplitMax);
						}
					
					
					}
					
			 }else{
			 
				confid12SplitMin = parseFloat(confid12Val);
				confid12ValArry.push(confid12SplitMin);
			 }
			 
			 
			 
			 	 if(confid23Val.indexOf("-")!=-1){
					confid23Split=confid23Val.split("-");
					confid23SplitMin = parseFloat(confid23Split[0].trim());
					confid23SplitMax = parseFloat(confid23Split[1].trim());
					
					
					if(confid23SplitMax==""){
						
						confid23ValArry.push(confid23SplitMin);
					}else{
						if(confid23SplitMax-confid23SplitMin<=0){
							alert("error in confid(2&3) value.")
						
						}else{
						
							confid23ValArry.push(confid23SplitMin);
							confid23ValArry.push(confid23SplitMax);
						}
					
					
					}
					
			 }else{
			 
				confid23SplitMin = parseFloat(confid23Val)
				confid23ValArry.push(confid23SplitMin);
			 }
			 
			 
			 
			 
             processJsonData(data,parseInt(noofRowTofilter),confid12ValArry,confid23ValArry);
			
			 
			 

}




	       function exportTableToCSV($table, filename) {
			
			
			
                var $headers = $table.find('tr:has(th)')
                    ,$rows = $table.find('tr:has(td)')
					
					

                    // Temporary delimiter characters unlikely to be typed by keyboard
                    // This is to avoid accidentally splitting the actual contents
                    ,tmpColDelim = String.fromCharCode(11) // vertical tab character
                    ,tmpRowDelim = String.fromCharCode(0) // null character

                    // actual delimiter characters for CSV format
                    ,colDelim = '","'
                    ,rowDelim = '"\r\n"';

                    // Grab text from table into CSV formatted string
                    var csv = '"';
                    csv += formatRows($headers.map(grabRow));
                    csv += rowDelim;
                    csv += formatRows($rows.map(grabRow)) + '"';

                    // Data URI
                    var csvData = 'data:application/csv;charset=utf-8,' + encodeURIComponent(csv);

                $(this)
                    .attr({
                    'download': filename
                        ,'href': csvData
                        //,'target' : '_blank' //if you want it to open in a new window
                });

                //------------------------------------------------------------
                // Helper Functions 
                //------------------------------------------------------------
                // Format the output so it has the appropriate delimiters
                function formatRows(rows){
                    return rows.get().join(tmpRowDelim)
                        .split(tmpRowDelim).join(rowDelim)
                        .split(tmpColDelim).join(colDelim);
                }
                // Grab and format a row from the table
                function grabRow(i,row){
                     
                    var $row = $(row);
                    //for some reason $cols = $row.find('td') || $row.find('th') won't work...
                    var $cols = $row.find('td'); 
                    if(!$cols.length) $cols = $row.find('th');  

                    return $cols.map(grabCol)
                                .get().join(tmpColDelim);
                }
                // Grab and format a column from the table 
                function grabCol(j,col){
                    var $col = $(col),
                        $text = $col.text();

                    return $text.replace('"', '""'); // escape double quotes

                }
            }
	
	
	
	function getGradientColor(i,data){
	
			var rainbow = new Rainbow(); 
			rainbow.setNumberRange(0, 1);
			rainbow.setSpectrum('red', 'green');

            var hexColour = rainbow.colourAt(i);
			
			return "#"+hexColour;

	
	}
	
	
	
function allowDrop(event) {
  

    event.preventDefault();
	
	
	setTimeout(function(){
		
		var activeTabHerf=$(".active").attr("href");
		
		
		
     if(activeTabHerf=="#tabs-home"){
			
	$('#my-awesome-dropzone').show();
	$("#formContainer").show();
	$("#formContainer").css("position","fixed");
	$("#formContainer").css("top","0px");
	$("#formContainer").css("left","0px");
	
	

	$("#my-awesome-dropzone").css("height",window.innerHeight+"px");
	$("#my-awesome-dropzone").css("width",window.innerWidth+"px");
	$("#my-awesome-dropzone").css("opacity",0.8);
	$("#my-awesome-dropzone img").css("margin-top",(window.innerHeight/2.5)+"px");
			
		}
		
	},200);
	
   
	
	
	
}


 function DragOver(event) {
  

  
  
  
    event.preventDefault();
	
	var activeTabHerf=$(".active").attr("href");
		
		
		
     if(activeTabHerf=="#tabs-home"){
		 
		 setTimeout(function(){
		$('#my-awesome-dropzone').hide();
	},2000)
		 
		 
	 }
	
	
	
   
}

function showUpload(event){
		event.preventDefault();
		$('#my-awesome-dropzone').trigger("click");
}



function addText(){
	
	
	$(".billboard-title").html(main_heading);
	$(".billboard-description").html(sub_heading);
	
	//$(".billboard").css("background-image","linear-gradient(to right, rgba(51,51,51,.8),rgba(51,51,51,.8)), url('http://placeimg.com/1000/400/tech/grayscale'); background-size: cover;");
	$("#tabHome").html(tab1_text);
	$("#tabSearch").html(tab2_text);
	var ths="";
	table_heading.forEach(function(d,i){
		
		ths=ths+"<th>"+d+"</th>";
	})
	var tr="<tr>"+ths+"</tr>";
	
	$("table thead").html(tr);
	
	$("#footerText").html(footer_text1+"<a href='' target='_blank' >"+footer_text2+"</a>");
	
	
}


